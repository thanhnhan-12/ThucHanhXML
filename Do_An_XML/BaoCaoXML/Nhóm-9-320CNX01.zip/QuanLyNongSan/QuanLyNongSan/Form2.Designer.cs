﻿namespace QuanLyNongSan
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonQLNongSan = new System.Windows.Forms.Button();
            this.buttonQLKhachHang = new System.Windows.Forms.Button();
            this.buttonLSThanhToan = new System.Windows.Forms.Button();
            this.buttonCapNhat = new System.Windows.Forms.Button();
            this.buttonXuatNS = new System.Windows.Forms.Button();
            this.buttonNhapNS = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.buttonQLNongSan);
            this.panel1.Controls.Add(this.buttonQLKhachHang);
            this.panel1.Controls.Add(this.buttonLSThanhToan);
            this.panel1.Controls.Add(this.buttonCapNhat);
            this.panel1.Controls.Add(this.buttonXuatNS);
            this.panel1.Controls.Add(this.buttonNhapNS);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(806, 355);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox1.Image = global::QuanLyNongSan.Properties.Resources.icon02__1_;
            this.pictureBox1.Location = new System.Drawing.Point(74, 130);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(39, 42);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox6.Image = global::QuanLyNongSan.Properties.Resources.icon05__1_;
            this.pictureBox6.Location = new System.Drawing.Point(451, 272);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(39, 42);
            this.pictureBox6.TabIndex = 14;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox5.Image = global::QuanLyNongSan.Properties.Resources.icon02__1_;
            this.pictureBox5.Location = new System.Drawing.Point(451, 205);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(39, 42);
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox4.Image = global::QuanLyNongSan.Properties.Resources.icon06__1_;
            this.pictureBox4.Location = new System.Drawing.Point(451, 121);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 42);
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox3.Image = global::QuanLyNongSan.Properties.Resources.icon06__1_;
            this.pictureBox3.Location = new System.Drawing.Point(74, 272);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(39, 42);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg04;
            this.pictureBox2.Image = global::QuanLyNongSan.Properties.Resources.icon05__1_;
            this.pictureBox2.Location = new System.Drawing.Point(74, 205);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 42);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.BackgroundImage = global::QuanLyNongSan.Properties.Resources.bg02;
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(842, 89);
            this.panel2.TabIndex = 8;
            this.panel2.TabStop = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Azure;
            this.pictureBox7.Image = global::QuanLyNongSan.Properties.Resources.icon06__2_;
            this.pictureBox7.Location = new System.Drawing.Point(91, 12);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(63, 60);
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.MintCream;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(172, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(443, 31);
            this.label3.TabIndex = 0;
            this.label3.Text = "MENU QUẢN LÝ BÁN NÔNG SẢN";
            // 
            // buttonQLNongSan
            // 
            this.buttonQLNongSan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonQLNongSan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQLNongSan.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonQLNongSan.Location = new System.Drawing.Point(120, 272);
            this.buttonQLNongSan.Margin = new System.Windows.Forms.Padding(4);
            this.buttonQLNongSan.Name = "buttonQLNongSan";
            this.buttonQLNongSan.Size = new System.Drawing.Size(213, 51);
            this.buttonQLNongSan.TabIndex = 7;
            this.buttonQLNongSan.Text = "Quản lý nông sản";
            this.buttonQLNongSan.UseVisualStyleBackColor = false;
            // 
            // buttonQLKhachHang
            // 
            this.buttonQLKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonQLKhachHang.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQLKhachHang.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonQLKhachHang.Location = new System.Drawing.Point(497, 121);
            this.buttonQLKhachHang.Margin = new System.Windows.Forms.Padding(4);
            this.buttonQLKhachHang.Name = "buttonQLKhachHang";
            this.buttonQLKhachHang.Size = new System.Drawing.Size(220, 51);
            this.buttonQLKhachHang.TabIndex = 6;
            this.buttonQLKhachHang.Text = "Quản lý khách hàng";
            this.buttonQLKhachHang.UseVisualStyleBackColor = false;
            this.buttonQLKhachHang.Click += new System.EventHandler(this.buttonQLKhachHang_Click);
            // 
            // buttonLSThanhToan
            // 
            this.buttonLSThanhToan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonLSThanhToan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLSThanhToan.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonLSThanhToan.Location = new System.Drawing.Point(497, 272);
            this.buttonLSThanhToan.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLSThanhToan.Name = "buttonLSThanhToan";
            this.buttonLSThanhToan.Size = new System.Drawing.Size(220, 51);
            this.buttonLSThanhToan.TabIndex = 5;
            this.buttonLSThanhToan.Text = "Lịch sử Thanh toán";
            this.buttonLSThanhToan.UseVisualStyleBackColor = false;
            // 
            // buttonCapNhat
            // 
            this.buttonCapNhat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonCapNhat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCapNhat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonCapNhat.Location = new System.Drawing.Point(497, 196);
            this.buttonCapNhat.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCapNhat.Name = "buttonCapNhat";
            this.buttonCapNhat.Size = new System.Drawing.Size(220, 51);
            this.buttonCapNhat.TabIndex = 4;
            this.buttonCapNhat.Text = "Cập nhật - Sao lưu Dữ liệu";
            this.buttonCapNhat.UseVisualStyleBackColor = false;
            this.buttonCapNhat.Click += new System.EventHandler(this.buttonCapNhat_Click);
            // 
            // buttonXuatNS
            // 
            this.buttonXuatNS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonXuatNS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonXuatNS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonXuatNS.Location = new System.Drawing.Point(120, 196);
            this.buttonXuatNS.Margin = new System.Windows.Forms.Padding(4);
            this.buttonXuatNS.Name = "buttonXuatNS";
            this.buttonXuatNS.Size = new System.Drawing.Size(213, 51);
            this.buttonXuatNS.TabIndex = 2;
            this.buttonXuatNS.Text = "Bán Nông Sản";
            this.buttonXuatNS.UseVisualStyleBackColor = false;
            this.buttonXuatNS.Click += new System.EventHandler(this.buttonXuatNS_Click);
            // 
            // buttonNhapNS
            // 
            this.buttonNhapNS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonNhapNS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNhapNS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonNhapNS.Location = new System.Drawing.Point(120, 121);
            this.buttonNhapNS.Margin = new System.Windows.Forms.Padding(4);
            this.buttonNhapNS.Name = "buttonNhapNS";
            this.buttonNhapNS.Size = new System.Drawing.Size(213, 51);
            this.buttonNhapNS.TabIndex = 1;
            this.buttonNhapNS.Text = "Nhập Nông Sản";
            this.buttonNhapNS.UseVisualStyleBackColor = false;
            this.buttonNhapNS.Click += new System.EventHandler(this.buttonNhapNS_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(810, 357);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "Menu Chính ";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonQLKhachHang;
        private System.Windows.Forms.Button buttonLSThanhToan;
        private System.Windows.Forms.Button buttonCapNhat;
        private System.Windows.Forms.Button buttonXuatNS;
        private System.Windows.Forms.Button buttonNhapNS;
        private System.Windows.Forms.Button buttonQLNongSan;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}